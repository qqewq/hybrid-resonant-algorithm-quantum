from hra.operators import ResonanceOperator, ResonanceParams
from hra.optimization import ResonanceSearch
from hra.utils import grid_candidates

def R_example(x):
    # игрушечная "резонансная" функция
    # чем ближе сумма к 0, тем выше значение
    s = sum(x)
    return max(0.0, 1.0 - abs(s))

if __name__ == "__main__":
    params = ResonanceParams(D=2.8, q_over_m=[1.0, 0.8, 0.7])
    R = ResonanceOperator(params)
    print("omega_res =", R.omega_res())

    # поиск кандидатов
    candidates = grid_candidates(n=3, span=1.0, points_per_dim=4)
    search = ResonanceSearch(threshold=0.7, max_points=400)
    selected = search.search(R_example, candidates)
    print("selected points:", len(selected))
    print("example standing wave Ψ(0.5, 1.0) =", R.standing_wave(0.5, 1.0))
