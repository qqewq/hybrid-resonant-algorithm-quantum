from typing import Sequence

class EthicsMetric:
    """Интерфейс этического коэффициента Γ.

    Здесь вы можете интегрировать собственные метрики и правила.
    """
    def gamma(self, dI_dt: Sequence[float], gamma_matrix: Sequence[Sequence[float]]) -> float:
        # Простая заглушка: сумма знаков изменения интеллекта, взвешенная γ_ij
        total = 0.0
        n = len(dI_dt)
        for i in range(n):
            sgn = 1.0 if dI_dt[i] > 0 else (-1.0 if dI_dt[i] < 0 else 0.0)
            for j in range(n):
                gij = gamma_matrix[i][j] if i < len(gamma_matrix) and j < len(gamma_matrix[i]) else 0.0
                total += sgn * gij
        return total
