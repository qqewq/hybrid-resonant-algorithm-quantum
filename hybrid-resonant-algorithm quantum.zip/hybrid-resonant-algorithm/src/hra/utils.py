import random
from typing import List, Sequence

def grid_candidates(n: int, span: float = 1.0, points_per_dim: int = 4) -> List[Sequence[float]]:
    """Грубая генерация сетки кандидатов в R^n."""
    # Для простоты — случайные точки в [-span, span]
    return [[random.uniform(-span, span) for _ in range(n)] for _ in range(points_per_dim ** n // max(1, n))]
