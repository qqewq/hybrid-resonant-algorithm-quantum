from typing import Optional
import tensorflow as tf

# Подключаем ваш каркас
try:
    from hra.operators import ResonanceOperator, ResonanceParams
except Exception:
    # Если пакет не установлен, дадим заглушку — чтобы пример не падал на импорте
    class ResonanceParams:  # type: ignore
        def __init__(self, D=2.0, q_over_m=(1.0, 1.0)): pass
    class ResonanceOperator:  # type: ignore
        def __init__(self, params): pass
        def omega_res(self): return 1.0

@tf.function
def hra_resonance_penalty(theta: tf.Tensor, lambda_reg: float = 0.05) -> tf.Tensor:
    """Пример «резонансного» штрафа: простая L2 + модификатор от ω_res.

    В реальном проекте подключите сюда ваши формулы R(H_i, x) и критерии отбора.
    """
    # theta — тензор параметров PQC (из trainable_weights слоя PQC)
    l2 = tf.reduce_mean(tf.square(theta))
    # toy ω_res от каркаса (константа для демонстрации)
    omega = tf.constant(1.0)
    return lambda_reg * (l2 / (1.0 + omega))
