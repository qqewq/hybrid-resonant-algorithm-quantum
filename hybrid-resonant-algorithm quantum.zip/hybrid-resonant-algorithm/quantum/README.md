# Quantum demo (TensorFlow Quantum + HRA)

Этот пример показывает, как встроить параметризованную квантовую схему (PQC, Cirq) в Keras-модель и добавить регуляризатор/метрику из каркаса HRA.

## Содержимое
- `train_tfq_demo.py` — минимальный обучающий скрипт.
- `hra_regularizer.py` — мост для расчёта «резонансной» добавки к функции потерь.
- `requirements-quantum.txt` — ориентировочные зависимости.

## Быстрый старт (локально)
> **Важно:** TensorFlow Quantum требует рабочую установку TensorFlow + Cirq. На CPU можно использовать симулятор Cirq.
```bash
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -U pip

# Поставьте зависимости (версии примерные, подберите под вашу ОС/CUDA):
pip install -r quantum/requirements-quantum.txt

# Установка локального пакета HRA (из корня репо)
pip install -e .

# Запуск демо
python quantum/train_tfq_demo.py
```

## Идея демо
1. Формируем Cirq-схему: data encoding (Rx) + вариационный блок (Ry + кольцевой CNOT).
2. Оборачиваем её в `tfq.layers.PQC`.
3. Строим Keras-модель: PQC → Dense → Head.
4. Используем `hra_regularizer.hra_resonance_penalty(...)` как добавку к лоссу.
