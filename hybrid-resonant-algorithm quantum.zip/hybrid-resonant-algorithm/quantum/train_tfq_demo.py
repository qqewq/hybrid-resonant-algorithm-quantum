import tensorflow as tf
import tensorflow_quantum as tfq
import cirq, sympy as sp
import numpy as np

from hra.utils import grid_candidates
from quantum.hra_regularizer import hra_resonance_penalty

# ----- 1) Схема: encoding + ansatz -----
n = 4
qubits = [cirq.LineQubit(i) for i in range(n)]

x_symbols = sp.symbols('x0:'+str(n))
enc = cirq.Circuit([cirq.rx(x_symbols[i])(qubits[i]) for i in range(n)])

theta = sp.symbols('t0:'+str(n))
ansatz = cirq.Circuit(
    [cirq.ry(theta[i])(qubits[i]) for i in range(n)] +
    [cirq.CNOT(qubits[i], qubits[(i+1)%n]) for i in range(n)]
)

model_circuit = enc + ansatz
readout = [cirq.Z(qubits[0])]

# ----- 2) Данные (игрушечные) -----
# Классификация: класс определяется знаком суммы фич
def make_data(num=256, dim=4):
    x = np.random.uniform(-1.0, 1.0, size=(num, dim)).astype(np.float32)
    y = (np.sum(x, axis=1) > 0).astype(np.int32)
    return x, y

x_train, y_train = make_data(512, n)
x_val, y_val = make_data(128, n)

def encode_batch(x_batch):
    # Строим список Cirq-схем с подстановкой чисел в символы x_i
    circuits = []
    for row in x_batch:
        substituted = cirq.resolve_parameters(enc, {x_symbols[i]: float(row[i]) for i in range(n)})
        circuits.append(substituted + ansatz)  # ansatz остаётся параметризованным
    return tfq.convert_to_tensor(circuits)

train_circuits = encode_batch(x_train)
val_circuits   = encode_batch(x_val)

# ----- 3) Модель Keras с PQC -----
pqc = tfq.layers.PQC(model_circuit, readout)

data_in = tf.keras.layers.Input(shape=(), dtype=tf.string)
y_q = pqc(data_in)
y = tf.keras.layers.Dense(16, activation='relu')(y_q)
out = tf.keras.layers.Dense(2)(y)
model = tf.keras.Model(inputs=data_in, outputs=out)

# ----- 4) Кастомный train-step с HRA-пенальти -----
opt = tf.keras.optimizers.Adam(1e-3)
ce = tf.keras.losses.SparseCategoricalCrossentropy(from_logits=True)

@tf.function
def train_step(circuits, labels):
    with tf.GradientTape() as tape:
        logits = model(circuits, training=True)
        loss_main = ce(labels, logits)

        # собираем trainable параметры PQC (обычно один вектор θ)
        pqc_weights = []
        for v in model.trainable_variables:
            if 'pqc' in v.name.lower():
                pqc_weights.append(tf.reshape(v, [-1]))
        theta = tf.concat(pqc_weights, axis=0) if pqc_weights else tf.zeros([1])

        loss_reg = hra_resonance_penalty(theta, lambda_reg=0.05)
        loss = loss_main + loss_reg

    grads = tape.gradient(loss, model.trainable_variables)
    opt.apply_gradients(zip(grads, model.trainable_variables))
    acc = tf.keras.metrics.sparse_categorical_accuracy(labels, logits)
    return loss, tf.reduce_mean(acc)

# ----- 5) Обучение -----
batch = 32
epochs = 3
for epoch in range(1, epochs+1):
    # train
    idx = np.random.permutation(len(x_train))
    x_train_b = train_circuits.numpy()[idx]
    y_train_b = y_train[idx]
    losses, accs = [], []
    for i in range(0, len(x_train_b), batch):
        c = tf.convert_to_tensor(x_train_b[i:i+batch])
        yb = tf.convert_to_tensor(y_train_b[i:i+batch])
        l, a = train_step(c, yb)
        losses.append(float(l.numpy()))
        accs.append(float(a.numpy()))
    print(f"Epoch {epoch}: loss={np.mean(losses):.4f} acc={np.mean(accs):.3f}")

# ----- 6) Валидация -----
logits = model(val_circuits, training=False).numpy()
y_pred = logits.argmax(axis=1)
acc_val = (y_pred == y_val).mean()
print("Val acc:", round(float(acc_val), 3))
